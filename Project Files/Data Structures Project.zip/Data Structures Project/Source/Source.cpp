#include <iostream>
#include <stack>
#include <queue>

using namespace std;



void main()
{
	// Change the title to Data Structures.
	system("title Data Structures");
	// Change color of font to dark green.
	system("color 0A");

	// Both the Stack and Queue being declared.
	stack<int> sStack;
	queue<int> qQueue;

	// Int values.
	int inputInt;
	int choice = 99;

	// Intro.
	cout << "Welcome to the Data Structures Program.";
	do
	{
		// User menu.
		cout << "\nMenu to manipulate integer stack and queue:\n";
		cout << "1: To PUSH/ENTER an integer on stack\n";
		cout << "2: To POP/REMOVE top integer from stack\n";
		cout << "3: To display the top element of the stack\n";
		cout << "4: To display the size of the stack\n";
		// Divider.
		cout << "---------------------------------------------------";
		cout << "\n5: To SHIFT/ENTER an integer on queue\n";
		cout << "6: To UNSHIFT/REMOVE an integer from queue\n";
		cout << "7: To display the top element of the queue\n";
		cout << "8: To display the size of the queue\n";
		// Divider
		cout << "---------------------------------------------------";
		cout << "\n9: Finish entering (END THE PROGRAM)\n";
		// Divider.
		cout << "---------------------------------------------------";
		// Asking for user input.
		cout << "\nPlease enter your choice (#): ";
		// Collect user input.
		cin >> choice;

		// Case scenarios set up for what number user inputs.
		switch (choice)
		{
		// Stack push member function.
		case 1:
			cout << "\nEnter an integer to Stack: ";
			cin >> inputInt;
			sStack.push(inputInt);
			break;
		// Stack pop member function.
		case 2:
			// Check if stack size is not empty.
			if (sStack.size() != 0)
			{
				cout << "\nPrevious Integer that is now removed: " << sStack.top();
				sStack.pop();
			}
			else
			{
				cout << "\nThere is nothing.";
			}
		// Stack top member function.
		case 3:
			cout << "\nThe top element of the STACK is now: " << sStack.top() << '\n';
			break;
		// Stack size member function.
		case 4:
			cout << "\n# of elements on STACK: " << sStack.size() << '\n';
			break;
		case 5:
		// Queue shift/push member function.
			cout << "\nEnter an integer to QUEUE: ";
			cin >> inputInt;
			qQueue.push(inputInt);
			break;
		// Queue unshift/pop member function.
		case 6:
			// Check if Queue size is not empty.
			if (qQueue.size() != 0)
			{
				cout << "\nPrevious Integer that is now removed: " << qQueue.front();
				qQueue.pop();
			}
			else
			{
				cout << "\nThere is nothing.";
			}
		// Queue front member function.
		case 7:
			cout << "\nThe top element of the QUEUE is: " << qQueue.front() << '\n';
			break;
		// Queue size member function.
		case 8:
			cout << "\n# of elements on QUEUE: " << qQueue.size();
			break;
		}
	} while (choice != 9); // While statement that will keep the program running until the user inputs the number 9.

	// Conclusion.
	cout << "\nEnd of Program...\n";
	cout << "Goodbye, have a nice day.\n";
	// Pause application.
	system("pause");
}
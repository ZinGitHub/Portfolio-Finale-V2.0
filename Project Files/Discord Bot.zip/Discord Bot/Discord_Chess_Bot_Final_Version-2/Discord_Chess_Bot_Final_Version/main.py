from flask import Flask, render_template, redirect, session, request
from flask_socketio import SocketIO, emit, join_room
from game_manager import GameManager, Player, GameState
from helpers import Parser, TemplateFiller
import threading
import secrets
import discord
import asyncio
import queue
import logging

# new event loop
discord_loop = asyncio.new_event_loop()

# discord client
client = discord.Client(loop=discord_loop)

# queue allowing flask to send messages through discord
flask_to_discord = queue.Queue()

# template filler
template_filler = TemplateFiller()

# game manager
manager = GameManager()

# flask app config and instance creation
app = Flask(__name__,
            template_folder="templates",
            static_folder="static")

app.config['SECRET_KEY'] = secrets.token_urlsafe(32)
socket_io = SocketIO(app)


# this async loop processes messages needing to be sent by flask to discord
async def flask_message_handler():
    # wait for the client to be ready
    await client.wait_until_ready()

    while not client.is_closed():
        if flask_to_discord.qsize() > 0:
            # get the request
            req = flask_to_discord.get()

            # send the message
            await req["channel"].send(
                content=req["content"],
                embed=discord.Embed.from_dict(req["embed"])
            )
        else:
            await asyncio.sleep(1)
            continue

# message event handler
@client.event
async def on_message(message):
    message_parse = None
    bot_handle = "<@" + str(client.user.id) + ">"

    # if the author is the bot then stop
    if message.author.id == client.user.id:
        return

    # check if the message is coming from a guild or a direct message from he user
    if isinstance(message.author, discord.user.User):
        message_parse = Parser(message.content)

    elif isinstance(message.author, discord.member.Member):
        # process messages coming from a guild
        if message.content.startswith('$chess') or message.content.startswith(bot_handle):
            message_parse = Parser(message.content, True)

    # if message is not import return
    if message_parse is None:
        return

    # get the first argument of the users message
    current_token = message_parse.next_arg()

    # create a dm with the user if none exists
    if message.author.dm_channel is None:
        await message.author.create_dm()

    # help command
    if current_token == "help":
        # get the first argument of the users message
        current_token = message_parse.next_arg()

        # handle next argument if it exists
        if current_token is None:
            # send the user the help message to their dms
            await message.author.dm_channel.send(embed=discord.Embed.from_dict(template_filler.fill_help_main_embed()))
        elif current_token == "commands":
            await message.author.dm_channel.send(embed=discord.Embed.from_dict(template_filler.fill_help_commands_embed()))
        else:
            await message.author.dm_channel.send(content="Incorrect usage of **help**, valid uses: "
                                                         "**help <commands | website>**")

        return
    elif current_token == "play":
        # block use of play in DMs
        if isinstance(message.author, discord.user.User):
            # setting the contents of the message
            await message.author.dm_channel.send(content="The **play** command does not work in DMs, please use it "
                                                         "from a server!")

            return

        # get the first argument of the users message
        current_token = message_parse.next_arg()

        if current_token is None:
            await message.channel.send(content="Incorrect use of the **play** command, please use **$chess help "
                                               "commands** for an example of proper syntax.")
            return
        else:
            opponent_id = ''.join(filter(lambda x: x.isdigit(), current_token))
            # remove non digits and check if the id is then blank
            if opponent_id == "":
                await message.channel.send(content="User given could not be found, please provide a proper @ mention "
                                           + "like " + bot_handle + ".")
                return
            else:
                # get the user id from the handle
                opponent = client.get_user(int(opponent_id))

            # check if the id returned a valid user
            if opponent is None:
                await message.channel.send(content="User given could not be found, please provide a proper @ mention "
                                           + "like " + bot_handle + ".")
                return

        # get the color choice of the requester
        current_token = message_parse.next_arg()

        # check for a side specification else it is random
        if current_token is None:
            requester_side = "r"
        elif current_token == "w":
            requester_side = "w"
        elif current_token == "b":
            requester_side = "b"
        elif current_token == "r":
            requester_side = "r"
        else:
            # if the user doesnt enter a correct color tell them what should be provided
            await message.channel.send(content="The provided side color was not valid, __must be__ one of the "
                                               "following: [**'w'** - for White, **'b'** - for Black, __or__ **'r'** - "
                                               "for Random Sides].")
            return

        # if the opponent user has no dm channel
        if not hasattr(opponent, "dm_channel"):
            await message.channel.send(content="The opponent you tried to challenge cannot receive direct messages!")
            return

        requester_data = Player(
            username=str(message.author),
            player_id=message.author.id,
            avatar_url=str(message.author.avatar_url)
        )

        opponent_data = Player(
            username=str(opponent),
            player_id=opponent.id,
            avatar_url=str(opponent.avatar_url)
        )

        # create the game
        session_url, new_game = manager.create_game(
            requester_player_data=requester_data,
            opponent_player_data=opponent_data,
            requester_color=requester_side,
            original_message=message,
            ranked=False,
            game_time="Infinite"
        )

        # convert true or false into yes or no string
        is_ranked = (lambda x: "Yes" if x else "No")(new_game.ranked)

        # <> send out the links to players <>

        # send the link to the game creator
        await message.author.dm_channel.send(
            embed=discord.Embed.from_dict(template_filler.fill_game_link_embed(
                opponent_username=opponent_data.username,
                opponent_avatar_url=opponent_data.avatar_url,
                ranked=is_ranked,
                time=new_game.time,
                requester_color=(lambda x, y: "White" if x == y else "Black")(requester_data.id, new_game.white.id),
                opponent_rating=str(opponent_data.elo),
                requester_link=str(requester_data.get_link())
            ))
        )

        # create a dm with the opponent if none exists
        if opponent.dm_channel is None:
            await opponent.create_dm()

        # send the invitation link to the opponent
        await opponent.dm_channel.send(
            embed=discord.Embed.from_dict(template_filler.fill_game_invite_embed(
                requester_username=requester_data.username,
                requester_avatar_url=requester_data.avatar_url,
                ranked=is_ranked,
                time=new_game.time,
                opponent_color=(lambda x, y: "White" if x == y else "Black")(opponent_data.id, new_game.white.id),
                requester_rating=str(requester_data.elo),
                opponent_link=str(opponent_data.get_link())
            ))
        )

        return
    else:
        # messages for invalid commands based on the message type (dm or guild)
        if isinstance(message.author, discord.user.User):
            await message.channel.send(content="The command **" + current_token
                                       + "** does not exist, try **help** to see a list of commands.")

        elif isinstance(message.author, discord.member.Member):
            await message.channel.send(content="The command `" + current_token
                                       + "` does not exist, try `$chess help` to see a list of commands.")
        return


# default route
@app.route('/')
def homepage():
    return redirect('/about')


# about page
@app.route('/about')
def about():
    return "About chessbot!"


# handles invite links to games, routing the player to the correct game link and setting their session info
@app.route('/join_game/<link_token>')
def join_game(link_token):
    # if the token could not be found in valid_join_tokens then player is None
    player, session_url = manager.get_player_info_from_token(link_token)

    if player is None:
        return "Link Has Expired or Been Used"

    # based on the link token assign the players name and id to their session info
    session[session_url + "-player_token"] = player.player_token

    return redirect("/game/" + session_url)


@app.route('/game/<session_url>')
def game(session_url):
    # if the game session_token is not valid then reroute
    if not manager.check_session(session_url):
        return redirect('/')

    # if the players session token is not valid then reroute
    if not manager.check_token(session_url, session[session_url + "-player_token"]):
        return redirect('/')

    # get this players id so we know which player they are
    game_data = manager.get_game_data(session_url, session[session_url + "-player_token"])

    app.logger.info(str(game_data["all_players_joined"]))

    # if this is the second player to join then tell the other player the game is starting and post spectator link
    if game_data["all_players_joined"] is True:
        # get the game object from the session_url
        current_game = manager.get_game(session_url)

        # only if the spectator link has not been sent do you send the link
        if current_game.sent_spectator_link is not True:

            # send the spectator link to the channel the game request was issued
            flask_to_discord.put(
                {
                    "channel": current_game.game_request_origin.channel,
                    "content": "",
                    "embed": template_filler.fill_spectator_invite_embed(
                        white_name=current_game.white.username,
                        black_name=current_game.black.username,
                        ranked=(lambda x: "Yes" if x else "No")(current_game.ranked),
                        time=str(current_game.time),
                        link=current_game.spectator_link()
                    )
                }
            )

            # tell the other player to also start the game
            socket_io.emit('start_game', True, room=session_url)

            # mark that the link has been sent
            current_game.sent_spectator_link = True

    # something went wrong if this is the case
    if game_data is None:
        return "Data Error"

    # render the page
    return render_template('play/chess_player.html', data=game_data)


@app.route('/spectate/<spectator_url>')
def spectate(spectator_url):
    # make sure the spectator link is valid
    if not manager.check_spectator(spectator_url):
        return "Spectator link is no longer valid!"

    spectator_data = manager.get_spectator_data(spectator_url)

    if spectator_data is None:
        return "Server Error"

    return render_template('spectate/chess_spectator.html', data=spectator_data)


@app.route('/replay')
def replay():
    # get the request arguments
    arguments = request.args

    if "white" in arguments and "black" in arguments and "pgn" in arguments:
        white = client.get_user(int(arguments["white"]))
        black = client.get_user(int(arguments["black"]))

        if white is None and black is None:
            return "Invalid Replay Link"

        replay_data = {
            "white": {
                "data": {
                    "name": str(white),
                    "avatar_url": str(white.avatar_url),
                    "rating": 1000
                }
            },
            "black": {
                "data": {
                    "name": str(black),
                    "avatar_url": str(black.avatar_url),
                    "rating": 1000
                }
            },
            "moves": arguments["pgn"].split("-")
        }

        return render_template('replay/chess_replay.html', data=replay_data)

    return "Invalid Replay Link"


@socket_io.on('verify_move')
def verify_move(data):
    verified, state, fen = manager.verify_move(data["session_url"], data)
    spectator_room_id = manager.get_spectator_url_from_game_url(data["session_url"])

    response = {
        "verified": verified,
        "state": state.value,
        "fen": fen
    }

    # if the move is just a normal move
    if state is GameState.NONE:
        # update the player's boards based on their own move and opponents move
        emit('player_update', response, room=data["session_url"])

        # spectator move update
        emit('spectator_update', response, room=spectator_room_id)

        return
    else:
        # update the player's boards based on their own move and opponents move
        emit('player_update', response, room=data["session_url"])

        # spectator move update
        emit('spectator_update', response, room=spectator_room_id)

        # get the current game so we can wrap it up
        current_game = manager.get_game(data["session_url"])

        # only if the spectator link has not been sent do you send the link
        if current_game.sent_game_result is not True:
            # the set the value to signify the result has been sent
            current_game.sent_game_result = True

            # send the spectator link to the channel the game request was issued
            flask_to_discord.put(
                {
                    "channel": current_game.game_request_origin.channel,
                    "content": "",
                    "embed": template_filler.fill_game_result_embed(
                        white_name=current_game.white.username,
                        black_name=current_game.black.username,
                        result=current_game.get_result(),
                        link=current_game.replay_link()
                    )
                }
            )

        # delete the game
        manager.delete_game(current_game)
        return


@socket_io.on('join_session')
def join_session(data):
    # join a room given any url
    join_room(data["session_token"])

    return


# add the message processing task to the client loop
client.loop.create_task(flask_message_handler())

# the discord start function
discord_start_routine = client.start("NjQ0OTI1NzU4OTcxNzA3NDE0.XeiS4g.v4k8vQdnUg8QMkT_T8Hi7AowTE4")


# function used to start the discord client loop
def start_loop(loop, routine):
    loop.run_until_complete(routine)


# thread running the discord client loop
client_thread = threading.Thread(
    target=start_loop,
    args=[discord_loop, discord_start_routine],
    daemon=False,
    name="Discord Client Thread"
)

# start the client thread
client_thread.start()

if __name__ == '__main__':

    # start flask app
    socket_io.run(app=app)


import chess
import secrets
import time
import datetime
import threading
import random
import enum

domain = "https://www.discordchess.com"  # "http://127.0.0.1:5000"


# definitions for the results of a game
class GameState(enum.Enum):
    STALEMATE = "stalemate"
    INSUFFICIENT_MATERIAL = "insufficient_material"
    THREEFOLD = "threefold"
    FIVEFOLD = "fivefold"
    FIFTY_MOVES = "fifty_moves"
    SEVENTYFIVE_MOVES = "seventyfive_moves"
    CHECKMATE = "checkmate"
    NONE = "none"


# player class for storing player data in the game manager (ai's count as players also)
class Player:
    def __init__(self, username, player_id, avatar_url):
        # used player info
        self.username = username
        self.id = player_id
        self.avatar_url = avatar_url

        # temporary
        self.elo = 1000

        # the token which is used to connect the player to their game session and identify them
        self.player_token = secrets.token_urlsafe(32)
        return

    # the link which allows a user to join a game as a given player
    def get_link(self):
        return domain + "/join_game/" + self.player_token

    # returns the players data as a dict
    def data(self):
        return {
            "name": self.username,
            "id": self.id,
            "avatar_url": self.avatar_url,
            "rating": self.elo
        }


# manages all ongoing games within the app
class GameManager:
    class Game:
        class CustomBoard(chess.Board):
            def __init__(self):
                super().__init__()
                self.reset()

            def verify_fen(self, fen):
                if fen == self.fen():
                    return True
                else:
                    return False

        def __init__(self, requester_player_data, opponent_player_data, requester_color, original_message, ranked,
                     game_time):
            # game session information
            self.session_url = secrets.token_urlsafe(32)

            # spectator session information
            self.spectator_url = secrets.token_urlsafe(32)

            # original message
            self.game_request_origin = original_message

            # match info
            self.ranked = ranked
            self.time = game_time

            # a datetime which represents the time at which the last action was made in this game
            self.last_action = datetime.datetime.now()

            # game board
            self.board = self.CustomBoard()

            # replay url pgn
            self.pgn = ""

            # message checks to avoid spam messages
            self.sent_spectator_link = False
            self.sent_game_result = False

            # player color definitions
            if requester_color == "w":
                self.white = requester_player_data
                self.black = opponent_player_data
            elif requester_color == "b":
                self.white = opponent_player_data
                self.black = requester_player_data
            else:
                # randomize the colors of the players
                if bool(random.getrandbits(1)):
                    self.white = requester_player_data
                    self.black = opponent_player_data
                else:
                    self.white = opponent_player_data
                    self.black = requester_player_data

            # player join urls, each works one time and then is removed from this list
            self.valid_join_tokens = [self.white.player_token, self.black.player_token]

            # player tokens, a convenient list
            self.perm_player_tokens = [self.white.player_token, self.black.player_token]
            return

        # resets the last_action datetime value to the current time
        def reset_timeout(self):
            self.last_action = datetime.datetime.now()

        # checks the current state of the board
        def current_state(self):
            if self.board.is_stalemate():
                return GameState.STALEMATE
            elif self.board.is_insufficient_material():
                return GameState.INSUFFICIENT_MATERIAL
            elif self.board.can_claim_threefold_repetition():
                return GameState.THREEFOLD
            elif self.board.can_claim_fifty_moves():
                return GameState.FIFTY_MOVES
            elif self.board.is_fivefold_repetition():
                return GameState.FIVEFOLD
            elif self.board.is_seventyfive_moves():
                return GameState.SEVENTYFIVE_MOVES
            elif self.board.is_checkmate():
                return GameState.CHECKMATE
            else:
                return GameState.NONE

        # gives the status if all players have accepted the game or not
        def players_accepted(self):
            if len(self.valid_join_tokens) == 0:
                return True
            return False

        # attempt to make a move, if the move is not valid then return false
        def make_move(self, move):
            # set the promotion
            move.promotion = chess.QUEEN

            # check if the move is valid with promotion
            if move in self.board.legal_moves:
                # if the move is legal then register it
                self.board.push(move)

                # add the move to the pgn
                self.pgn += move.uci() + "-"

                # return the move was validated
                return True

            # if promotion move fails then try move without promotion
            move.promotion = None

            # check if the move is valid without promotion
            if move in self.board.legal_moves:
                # if the move is legal then register it
                self.board.push(move)

                # add the move to the pgn
                self.pgn += move.uci() + "-"

                # return the move was validated
                return True
            else:
                # return that the move was not validated
                return False

        # check if a move is a valid move returns a bool
        def check_move(self, move):
            # set the promotion
            move.promotion = chess.QUEEN

            # check if the move is valid with promotion
            if move in self.board.legal_moves:
                # return the move was validated
                return True

            # if promotion move fails then try move without promotion
            move.promotion = None

            # check if the move is valid without promotion
            if move in self.board.legal_moves:
                # return the move was validated
                return True
            else:
                # return that the move was not validated
                return False

        # compare the fen of the client board and the server board and update based on that
        def fen(self):
            return self.board.fen()

        # checks if the game session has timed out returns a bool
        def session_timed_out(self):
            time_delta = datetime.datetime.now() - self.last_action

            # check if the difference between the current time and the time since the last action is 15 min or more
            if time_delta >= datetime.timedelta(minutes=15):
                return True
            else:
                return False

        # returns the game info necessary for the game client side, formatted by player
        def game_info(self, player_token):
            if self.white.player_token == player_token:
                return {
                    "all_players_joined": self.players_accepted(),
                    "session_url": self.session_url,
                    "current_fen": self.board.fen(),
                    "is_ranked": self.ranked,
                    "player": {
                        "color": "w",
                        "data": self.white.data()
                    },
                    "opponent": {
                        "color": "b",
                        "data": self.black.data()
                    }
                }
            elif self.black.player_token == player_token:
                return {
                    "all_players_joined": self.players_accepted(),
                    "session_url": self.session_url,
                    "current_fen": self.board.fen(),
                    "is_ranked": self.ranked,
                    "player": {
                        "color": "b",
                        "data": self.black.data()
                    },
                    "opponent": {
                        "color": "w",
                        "data": self.white.data()
                    }
                }
            else:
                return None

        def spectator_info(self):
            return {
                "spectator_url": self.spectator_url,
                "current_fen": self.board.fen(),
                "is_ranked": self.ranked,
                "white": {
                    "data": self.black.data()
                },
                "black": {
                    "data": self.white.data()
                }
            }

        # returns the result of the game as a explanation string
        def get_result(self):
            if self.board.is_stalemate():
                return "The game ended in a **Draw** due to a __Stalemate__."
            elif self.board.is_insufficient_material():
                return "The game ended in a **Draw** due to __Insufficient Material__."
            elif self.board.can_claim_threefold_repetition():
                return "The game ended in a **Draw** due to __Threefold Repetition__."
            elif self.board.can_claim_fifty_moves():
                return "The game ended in a **Draw** due to the __Fifty Move Rule__."
            elif self.board.is_fivefold_repetition():
                return "The game ended in a **Draw** due to __Fivefold Repetition__."
            elif self.board.is_seventyfive_moves():
                return "The game ended in a **Draw** due to the __Seventyfive Move Rule__."
            elif self.board.is_checkmate():
                if self.board.turn == chess.WHITE:
                    return "The game ended in **Checkmate** from Black, making **" + self.black.username \
                           + "** the winner."
                else:
                    return "The game ended in **Checkmate** from White, making **" + self.white.username \
                           + "** the winner."

        def spectator_link(self):
            return domain + "/spectate/" + self.spectator_url

        def replay_link(self):
            replay_data = ("?white=" + str(self.white.id) + "&black=" + str(self.black.id) + "&pgn=" + self.pgn + "end"
                           + "-" + self.current_state().value)
            return domain + "/replay" + replay_data

        # return the game session info as a tuple (session_url, session_secret)
        def session_info(self):
            return (
                self.session_url
            )

    def __init__(self, timeout_check_delay=15):
        # the delay between checking if games are still alive
        self.timeout_check_delay = timeout_check_delay

        # a list of current ongoing games
        self.__games = []

        # a list of background task threads
        self.__threads = []

        # start background threads
        self.__start_threads()

    # check if a given session url has a matching game in the manager
    def check_session(self, session_url):
        # check if a given session_url exists
        for game in self.__games:
            if game.session_url == session_url:
                return True
        return False

    # check if a given spectator url has a matching game in the manager
    def check_spectator(self, spectator_url):
        # check if a given spectator_url exists
        for game in self.__games:
            if game.spectator_url == spectator_url:
                return True
        return False

    # check if a players token is valid for a given session
    def check_token(self, session_url, player_token):
        for game in self.__games:
            if game.session_url == session_url:
                if player_token in game.perm_player_tokens:
                    return True
        return False

    # creates a new game with some given player data
    def create_game(self, requester_player_data, opponent_player_data, requester_color, original_message, ranked,
                    game_time):
        # create a new game
        new_game = self.Game(requester_player_data, opponent_player_data, requester_color, original_message, ranked,
                             game_time)

        # add the game to the list
        self.__games.append(new_game)

        # return the new games session info
        return new_game.session_info(), new_game

    # get the player data of a given game given its url token and the player's token to personalize the data
    def get_game_data(self, session_url, player_token):
        for game in self.__games:
            if game.session_url == session_url:
                return game.game_info(player_token)
        return None

    # spectator data by url
    def get_spectator_data(self, spectator_url):
        for game in self.__games:
            if game.spectator_url == spectator_url:
                return game.spectator_info()
        return None

    def get_spectator_url_from_game_url(self, session_url):
        for game in self.__games:
            if game.session_url == session_url:
                return game.spectator_url
        return None

    # check the state of a given board
    def check_state(self, session_url):
        # find the game with the matching session_url
        for game in self.__games:
            if game.session_url == session_url:
                return game.current_state()
        return None

    # gets a channel object based on the game url
    def get_game(self, session_url):
        for game in self.__games:
            if game.session_url == session_url:
                return game
        return None

    # verify a move sent by a client
    def verify_move(self, session_url, move):
        # find the game with the matching session_url
        for game in self.__games:
            # resets the game's timeout counter
            game.reset_timeout()

            if game.session_url == session_url:
                # verify the move
                verification_status = game.make_move(
                    chess.Move.from_uci(move["move"]["source"] + move["move"]["target"]))

                # get the board state
                board_state = game.current_state()

                # board fen
                board_fen = game.board.fen()

                return verification_status, board_state, board_fen
        return None

    # returns the fen of a given board
    def get_fen(self, session_url):
        for game in self.__games:
            if game.session_url == session_url:
                return game.board.fen()
        return None

    # returns the player object and session token given the player url
    def get_player_info_from_token(self, player_token):
        for game in self.__games:
            print("found_game with tokens" + str(game.valid_join_tokens))
            for token in game.valid_join_tokens:
                print("searching for token: " + token)
                if token == player_token:
                    print("token march found")
                    if game.black.player_token == player_token:
                        print("black player token")
                        game.valid_join_tokens.remove(player_token)
                        return (game.black,
                                game.session_info())
                    elif game.white.player_token == player_token:
                        print("white player token")
                        game.valid_join_tokens.remove(player_token)
                        return (game.white,
                                game.session_info())
        return None, None

    def delete_game(self, game):
        self.__games.remove(game)

    # checks the timeout of games and will delete the game if it has timed out
    def __check_timeouts(self):
        while True:
            # delay between checks
            time.sleep(self.timeout_check_delay)

            # check if each game has timed out
            for game in self.__games:
                # if the game has  timed out remove it from the list of ongoing games
                if game.session_timed_out():
                    self.__games.remove(game)

    # starts all background task threads of the manager
    def __start_threads(self):
        # add the thread which checks the game timeouts
        self.__threads.append(threading.Thread(target=self.__check_timeouts, daemon=False))

        # start all of the threads
        for thread in self.__threads:
            thread.start()




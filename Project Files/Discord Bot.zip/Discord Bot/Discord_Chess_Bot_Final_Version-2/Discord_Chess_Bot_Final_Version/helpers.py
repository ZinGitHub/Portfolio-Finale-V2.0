from collections import deque
from copy import deepcopy
import json


# a class used for parsing commands easier
class Parser:
    def __init__(self, command, remove_identifier=False):
        # tokenized commands
        self.command_tokens = deque(' '.join(command.split()).split(" "))

        if remove_identifier:
            self.command_tokens.popleft()

    # returns the next argument or None if there is no next argument (always in lowercase)
    def next_arg(self):
        if len(self.command_tokens) != 0:
            return self.command_tokens.popleft().lower()

        return None

    # returns the # of remaining arguments
    def args_remaining(self):
        return len(self.command_tokens)


class TemplateFiller:
    def __init__(self):
        with open("embeds/game_invite.json") as file:
            self.__game_invite_embed = json.load(file)

        with open("embeds/game_link.json") as file:
            self.__game_link_embed = json.load(file)

        with open("embeds/spectator_link.json") as file:
            self.__spectator_link_embed = json.load(file)

        with open("embeds/help_main.json") as file:
            self.__help_main_embed = json.load(file)

        with open("embeds/help_commands.json") as file:
            self.__help_commands_embed = json.load(file)

        with open("embeds/game_result.json") as file:
            self.__game_result_embed = json.load(file)

    def fill_help_main_embed(self):
        return self.__help_main_embed

    def fill_help_commands_embed(self):
        return self.__help_commands_embed

    def fill_game_link_embed(self, opponent_username, opponent_avatar_url, ranked, time, requester_color,
                             opponent_rating, requester_link):
        link_template = deepcopy(self.__game_link_embed)

        link_template["description"] = link_template["description"].replace("{user}", opponent_username)
        link_template["thumbnail"]["url"] = opponent_avatar_url
        link_template["fields"][0]["value"] = link_template["fields"][0]["value"].replace("{ranked}", ranked)
        link_template["fields"][0]["value"] = link_template["fields"][0]["value"].replace("{time}", time)
        link_template["fields"][0]["value"] = link_template["fields"][0]["value"].replace("{color}", requester_color)
        link_template["fields"][1]["value"] = link_template["fields"][1]["value"].replace("{elo}", str(opponent_rating))
        link_template["fields"][2]["value"] = link_template["fields"][2]["value"].replace("{link}", requester_link)

        return link_template

    def fill_game_invite_embed(self, requester_username, requester_avatar_url, ranked, time, opponent_color,
                               requester_rating, opponent_link):
        invite_template = deepcopy(self.__game_invite_embed)

        invite_template["description"] = invite_template["description"].replace("{user}", requester_username)
        invite_template["thumbnail"]["url"] = requester_avatar_url
        invite_template["fields"][0]["value"] = invite_template["fields"][0]["value"].replace("{ranked}", ranked)
        invite_template["fields"][0]["value"] = invite_template["fields"][0]["value"].replace("{time}", time)
        invite_template["fields"][0]["value"] = invite_template["fields"][0]["value"].replace("{color}", opponent_color)
        invite_template["fields"][1]["value"] = invite_template["fields"][1]["value"].replace("{elo}",
                                                                                              str(requester_rating))
        invite_template["fields"][2]["value"] = invite_template["fields"][2]["value"].replace("{link}", opponent_link)

        return invite_template

    def fill_spectator_invite_embed(self, white_name, black_name, ranked, time, link):
        spectator_template = deepcopy(self.__spectator_link_embed)

        spectator_template["description"] = spectator_template["description"].replace("{white}", white_name)
        spectator_template["description"] = spectator_template["description"].replace("{black}", black_name)
        spectator_template["fields"][0]["value"] = spectator_template["fields"][0]["value"].replace("{white}",
                                                                                                    white_name)
        spectator_template["fields"][0]["value"] = spectator_template["fields"][0]["value"].replace("{black}",
                                                                                                    black_name)
        spectator_template["fields"][1]["value"] = spectator_template["fields"][1]["value"].replace("{ranked}", ranked)
        spectator_template["fields"][1]["value"] = spectator_template["fields"][1]["value"].replace("{time}", time)
        spectator_template["fields"][2]["value"] = spectator_template["fields"][2]["value"].replace("{link}", link)

        return spectator_template

    def fill_game_result_embed(self, white_name, black_name, result, link):
        game_result_embed = deepcopy(self.__game_result_embed)

        game_result_embed["description"] = game_result_embed["description"].replace("{white}", white_name)
        game_result_embed["description"] = game_result_embed["description"].replace("{black}", black_name)
        game_result_embed["fields"][0]["value"] = game_result_embed["fields"][0]["value"].replace("{result}", result)
        game_result_embed["fields"][1]["value"] = game_result_embed["fields"][1]["value"].replace("{link}", link)

        return game_result_embed

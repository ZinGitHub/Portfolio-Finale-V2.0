Class Diagram - Refer to Software Requirements Specification.
Sequence Diagram - Refer to Software Requirements Specification.
2 Use Case Diagrams - Refer to Software Requirements Specification.
UX Diagram - Refer to Software Requirements Specification.